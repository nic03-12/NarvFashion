<?php

	/* @Autor: Dalker Pinheiro
	   Atributos e métodos da classe */
	   
	class Produto{
		//Atributos
		private $codProduto;
 		private $nomeProduto;
 		private $idProduto;
 		private $tipoProduto;
 		private $fotoProduto;
 		private $precoProduto;
 		private $quantidadeProduto;
 				
		//Métodos Getters e Setters
		public function getCodProduto(){
			return $this->codProduto;
		}
		public function getNomeProduto(){
			return $this->nomeProduto;
		}
		public function getIdProduto(){
			return $this->idProduto;
		}
		public function getTipoProduto(){
			return $this->tipoProduto;
		}
		public function getFotoProduto(){
			return $this->fotoProduto;
		}
		public function getPrecoProduto(){
			return $this->precoProduto;
		}
		public function getQuantidadeProduto(){
			return $this->quantidadeProduto;
		}
		
		public function setCodProduto($codProduto){
			$this->codProduto=$codProduto;
		}
		public function setNomeProduto($nomeProduto){
			$this->nomeProduto=$nomeProduto;
		}
		public function setIdProduto($idProduto){
			$this->idProduto=$idProduto;
		}
		public function setTipoProduto($tipoProduto){
			$this->tipoProduto=$tipoProduto;
		}
		public function setFotoProduto($fotoProduto){
			$this->fotoProduto=$fotoProduto;
		}
		public function setPrecoProduto($precoProduto){
			$this->precoProduto=$precoProduto;
		}
		public function setQuantidadeProduto($quantidadeProduto){
			$this->quantidadeProduto=$quantidadeProduto;
		}
	}	
?>