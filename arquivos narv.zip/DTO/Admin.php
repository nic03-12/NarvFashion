<?php		
	class Admin{
		//Atributos
		private $codAdmin;
 		private $nomeAdmin;
 		private $loginAdmin;
 		private $senhaAdmin;
 		private $emailAdmin;
 		private $fotoAdmin;
 				
		//Métodos Getters e Setters
		public function getCodAdmin(){
			return $this->codAdmin;
		}
		public function getNomeAdmin(){
			return $this->nomeAdmin;
		}
		public function getLoginAdmin(){
			return $this->loginAdmin;
		}
		public function getSenhaAdmin(){
			return $this->senhaAdmin;
		}
		public function getEmailAdmin(){
			return $this->emailAdmin;
		}
		public function getFotoAdmin(){
			return $this->fotoAdmin;
		}
		
		public function setCodAdmin($codAdmin){
			$this->codAdmin=$codAdmin;
		}
		public function setNomeAdmin($nomeAdmin){
			$this->nomeAdmin=$nomeAdmin;
		}
		public function setLoginAdmin($loginAdmin){
			$this->loginAdmin=$loginAdmin;
		}
		public function setSenhaAdmin($senhaAdmin){
			$this->senhaAdmin=$senhaAdmin;
		}
		public function setEmailAdmin($emailAdmin){
			$this->emailAdmin=$emailAdmin;
		}
		public function setFotoAdmin($fotoAdmin){
			$this->fotoAdmin=$fotoAdmin;
		}
		
	}
?>