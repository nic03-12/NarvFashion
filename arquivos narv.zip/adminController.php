<?php  
	require_once ("include_dao.php");
	
	$acao= isset($_POST['acao']) ? $_POST['acao'] : "";
	$pesquisaAdmin = isset($_GET['pesquisaAdmin']) ? $_GET['pesquisaAdmin'] : "";
	
	$adminModel= new admin();
	$adminDAO= new adminDAO();

	if(empty($pesquisaAdmin)){
		$admins = $adminDAO -> listarTodosAdmin();
	}
	else{
		$admins = $adminDAO->listarAdmin($pesquisaAdmin);
	}

	if ($acao == "Logar") {
		$login= isset($_POST['login']) ? $_POST['login'] : "";
	    $senha= isset($_POST['senha']) ? $_POST['senha'] : "";
	
	    $resultado = $usuarioDAO->logar($login, $senha);

	    if ($resultado == false) {
	   		echo '<center><span style="color:red;text-align:center;">Login ou senha incorretos!</span></center>';
	    }
		else{
			session_start();
			$_SESSION["usuario"] = $login;
			header("location:index.php");
		}
	}
	if ($acao == "LogarComoAdm"){
		$loginAdmin= isset($_POST['loginAdmin']) ? $_POST['loginAdmin'] : "";
	    $senhaAdmin= isset($_POST['senhaAdmin']) ? $_POST['senhaAdmin'] : "";
	
	    $resultado = $usuarioDAO->logar($loginAdmin, $senhaAdmin);

	    if ($resultado == false) {
	   		echo '<center><span style="color:red;text-align:center;">Login ou senha incorretos!</span></center>';
	    }
		else{
			session_start();
			$_SESSION["admin"] = $loginAdmin;
			header("location:adminView.php");
		}
	}
	else if ($acao=="AdicionarAdmin") {

		$fotoAdmin = isset($_FILES['fotoAdmin']) ? $_FILES['fotoAdmin'] : "";

		if(!empty($fotoAdmin['name']) and ($fotoAdmin['type'] == "image/jpeg" or $fotoAdmin['type'] == "image/jpg" or $fotoAdmin['type'] == "image/png")){
			$resultado = explode(".", $fotoAdmin['name']);
			$nome = $resultado[0];
			$tipo = $resultado[1];
			$novoNome = ("admin-".md5(time()*rand()).".".$tipo);
			$destino = "imgs/admins/$novoNome";
			move_uploaded_file($fotoAdmin["tmp_name"], $destino);
		}else{
			$novoNome = "semfoto.png";
		}

		$adminModel->setFotoAdmin($novoNome);

	    $nomeAdmin= isset($_POST['nomeAdmin']) ? $_POST['nomeAdmin'] : "";
	    $emailAdmin= isset($_POST['emailAdmin']) ? $_POST['emailAdmin'] : "";
	    $loginAdmin= isset($_POST['loginAdmin']) ? $_POST['loginAdmin'] : "";
	    $senhaAdmin= isset($_POST['senhaAdmin']) ? $_POST['senhaAdmin'] : "";
	
		$adminModel->setNomeAdmin($nomeAdmin);
		$adminModel->setEmailAdmin($emailAdmin);
		$adminModel->setLoginAdmin($loginAdmin);
		$adminModel->setSenhaAdmin($senhaAdmin);

	 	$resultado = $adminDAO->inserir($adminModel);
	 header("location:adminView.php?msg=adicionado");
	}
	else if ($acao=="CadastrarAdmin") {
	    $nomeAdmin= isset($_POST['nomeAdmin']) ? $_POST['nomeAdmin'] : "";
	    $emailAdmin= isset($_POST['emailAdmin']) ? $_POST['emailAdmin'] : "";
	    $loginAdmin= isset($_POST['loginAdmin']) ? $_POST['loginAdmin'] : "";
	    $senhaAdmin= isset($_POST['senhaAdmin']) ? $_POST['senhaAdmin'] : "";
	
		$adminModel->setNomeAdmin($nomeAdmin);
		$adminModel->setEmailAdmin($emailAdmin);
		$adminModel->setLoginAdmin($loginAdmin);
		$adminModel->setSenhaAdmin($senhaAdmin);

	 	$resultado = $adminDAO->inserir($adminModel);
	 header("location:cadastro.php?msg=adicionado");	
	}		
	else if ($acao=="ApagarAdmin") {
	    $codAdmin= isset($_POST['codAdmin']) ? $_POST['codAdmin'] : "";
	 	$adminDAO->deletar($codAdmin);
	 	header("location:adminView.php?msg=excluido");
	}		
	else if ($acao=="EditarAdmin"){
	    $adminModel->setCodAdmin(isset($_POST['codAdmin']) ? $_POST['codAdmin'] : "");
	    $adminModel->setNomeAdmin(isset($_POST['nomeAdmin']) ? $_POST['nomeAdmin'] : "");
	    $adminModel->setEmailAdmin(isset($_POST['emailAdmin']) ? $_POST['emailAdmin'] : "");
	    $adminModel->setLoginAdmin(isset($_POST['loginAdmin']) ? $_POST['loginAdmin'] : "");
	    $adminModel->setSenhaAdmin(isset($_POST['senhaAdmin']) ? $_POST['senhaAdmin'] : "");
	    $cod = isset($_POST['codAdmin']) ? $_POST['codAdmin'] : "";
	    $fotoAntiga = $adminDAO->buscarFotoPorCodigo($codAdmin);

	    if(!empty(isset($_FILES['fotoAdmin']) ? $_FILES['fotoAdmin'] : "")) {
			$novaFoto = isset($_FILES['fotoAdmin']) ? $_FILES['fotoAdmin'] : "";
		    $resultado = explode(".", $novaFoto["name"]);
		    $nomeNovaFoto = $resultado[0];
		    $tipoArqNovo = $resultado[1];
		    if ($tipoArqNovo == "png" or $tipoArqNovo == "jpg" or $tipoArqNovo == "jpeg"){
		        $novoNovoNome = "adminstrador-".md5(time()*rand()).".".$tipoArqNovo;
		        move_uploaded_file($novaFoto["tmp_name"], "imgs/admins/$novoNovoNome");
				$adminModel->setFotoAdmin($novoNovoNome);
		        $adminDAO->atualizar($adminModel);    
			} else {
		        $adminDAO->atualizarSemFoto($adminModel);    
			}
		}
		//apagador de imag
		if (!empty($fotoAntiga)) {
	        $caminhoFotoAntiga = "imgs/admins/" . $fotoAntiga;
	        if (file_exists($caminhoFotoAntiga)) {
	            unlink($caminhoFotoAntiga);
	        }
	    }
		header("location:adminView.php?msg=editado");
			
		}				

?>