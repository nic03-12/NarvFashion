function excluirUsuario(cod){
	document.getElementById('excluirCod').value = cod;
}
function editarUsuario(cod, nome, email, login, senha, foto){
	document.getElementById('editarCod').value = cod;
	document.getElementById('editarNome').value = nome;
	document.getElementById('editarEmail').value = email;
	document.getElementById('editarLogin').value = login;
	document.getElementById('editarSenha').value = senha;
	document.getElementById('editarFoto').src = "imgs/usuarios/"+foto;
	document.getElementById("alertas").style.display="none";
}

function excluirAdmin(codAdmin){
	document.getElementById('excluirCodAdmin').value = codAdmin;
}
function editarAdmin(codAdmin, nomeAdmin, emailAdmin, loginAdmin, senhaAdmin, fotoAdmin){
	document.getElementById('editarCodAdmin').value = codAdmin;
	document.getElementById('editarNomeAdmin').value = nomeAdmin;
	document.getElementById('editarEmailAdmin').value = emailAdmin;
	document.getElementById('editarLoginAdmin').value = loginAdmin;
	document.getElementById('editarSenhaAdmin').value = senhaAdmin;
	document.getElementById('editarFotoAdmin').src = "imgs/admins/"+fotoAdmin;
	document.getElementById("alertas").style.display="none";
}
function excluirProduto(codProduto){
	document.getElementById('excluirCodProduto').value = codProduto;
}
function editarProduto(codProduto, idProduto, tipoProduto, nomeProduto, fotoProduto, precoProduto, quantidadeProduto){
	document.getElementById('editarCodProduto').value = codProduto;
	document.getElementById('editarIdProduto').value = idProduto;
	document.getElementById('editarTipoProduto').value = tipoProduto;
	document.getElementById('editarNomeProduto').value = nomeProduto;
	document.getElementById('editarFotoProduto').src = "imgs/produtos/"+fotoProduto;
	document.getElementById('editarPrecoProduto').value = precoProduto;
	document.getElementById('editarQuantidadeProduto').value = quantidadeProduto;
	document.getElementById("alertas").style.display="none";	
}
function adicionarProduto(cod){
    var dados = JSON.stringify(cod);
    $.ajax({
        url: 'adicionaCarrinho.php',
        type: 'POST',
        data: {data: dados},

        success: function(result){
        	
        },
        error: function(jqXHR, textStatus, errorThrown) {
          // Retorno caso algum erro ocorra
        }

    });


}
function removeProduto(cod) {
    var codProduto = JSON.stringify(cod);

    $.ajax({
        url: 'carrinho.php', 
        method: 'POST',
        data: { cod: codProduto }, 
        success: function(response) {
       
            window.location.reload(); 
        },
        error: function(xhr, status, error) {
      
            console.error(error);
         
        }
    });
}

$(document).ready(function(){
	// Activate tooltip
	$('[data-toggle="tooltip"]').tooltip();
	
	// Select/Deselect checkboxes
	var checkbox = $('table tbody input[type="checkbox"]');
	$("#selectAll").click(function(){
		if(this.checked){
			checkbox.each(function(){
				this.checked = true;                        
			});
		} else{
			checkbox.each(function(){
				this.checked = false;                        
			});
		} 
	});
	checkbox.click(function(){
		if(!this.checked){
			$("#selectAll").prop("checked", false);
		}
	});
});