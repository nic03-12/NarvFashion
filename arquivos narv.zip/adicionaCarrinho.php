<?php
  session_start();
  $dados = $_POST['data'];
  $novoItem = json_decode($dados, true);
  array_push($_SESSION['carrinho'], $novoItem);
  header("location:category.php");


if(isset($_POST['cod'])) {
    $codProduto = $_POST['cod'];

    if (($key = array_search($codProduto, $_SESSION['carrinho'])) !== false) {
        unset($_SESSION['carrinho'][$key]);
     
        echo "Produto removido do carrinho com sucesso.";
    } 
} 
?>
