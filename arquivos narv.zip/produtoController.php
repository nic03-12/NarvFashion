<?php  
	require_once ("include_dao.php");
	
	$acao= isset($_POST['acao']) ? $_POST['acao'] : "";
	$pesquisaProduto = isset($_GET['pesquisaProduto']) ? $_GET['pesquisaProduto'] : "";
	
	$produtoModel= new produto();
	$produtoDAO= new produtoDAO();

	if(empty($pesquisaProduto)){
		$produtos = $produtoDAO -> listarTodosProduto();
	}
	else{
		$produtos = $produtoDAO->listarProduto($pesquisaProduto);
	}

	if ($acao=="AdicionarProduto") {

		$fotoProduto = isset($_FILES['fotoProduto']) ? $_FILES['fotoProduto'] : "";

		if(!empty($fotoProduto['name']) and ($fotoProduto['type'] == "image/jpeg" or $fotoProduto['type'] == "image/jpg" or $fotoProduto['type'] == "image/png")){
			$resultado = explode(".", $fotoProduto['name']);
			$nome = $resultado[0];
			$tipo = $resultado[1];
			$novoNome = ("produto-".md5(time()*rand()).".".$tipo);
			$destino = "imgs/produtos/$novoNome";
			move_uploaded_file($fotoProduto["tmp_name"], $destino);
		}else{
			$novoNome = "semfoto.png";
		}

		$produtoModel->setFotoProduto($novoNome);


	    $idProduto= isset($_POST['idProduto']) ? $_POST['idProduto'] : "";
		$tipoProduto= isset($_POST['tipoProduto']) ? $_POST['tipoProduto'] : "";
	    $nomeProduto= isset($_POST['nomeProduto']) ? $_POST['nomeProduto'] : "";
	    $precoProduto= isset($_POST['precoProduto']) ? $_POST['precoProduto'] : "";
	    $quantidadeProduto= isset($_POST['quantidadeProduto']) ? $_POST['quantidadeProduto'] : "";
	
		$produtoModel->setIdProduto($idProduto);
		$produtoModel->setTipoProduto($tipoProduto);
		$produtoModel->setNomeProduto($nomeProduto);
		$produtoModel->setPrecoProduto($precoProduto);
		$produtoModel->setQuantidadeProduto($quantidadeProduto);

	 	$resultado = $produtoDAO->inserir($produtoModel);
	 	header("location:adminView.php?msg=adicionado");	
	} 	
	else if ($acao=="ApagarProduto") {
	    $codProduto= isset($_POST['codProduto']) ? $_POST['codProduto'] : "";
	 	$produtoDAO->deletar($codProduto);
	 	header("location:adminView.php?msg=excluido");
	}		
	else if ($acao=="EditarProduto"){
	    $produtoModel->setCodProduto(isset($_POST['codProduto']) ? $_POST['codProduto'] : "");
	    $produtoModel->setIdProduto(isset($_POST['idProduto']) ? $_POST['idProduto'] : "");
	    $produtoModel->setTipoProduto(isset($_POST['tipoProduto']) ? $_POST['tipoProduto'] : "");
	    $produtoModel->setNomeProduto(isset($_POST['nomeProduto']) ? $_POST['nomeProduto'] : "");
	    $produtoModel->setPrecoProduto(isset($_POST['precoProduto']) ? $_POST['precoProduto'] : "");
	    $produtoModel->setQuantidadeProduto(isset($_POST['quantidadeProduto']) ? $_POST['quantidadeProduto'] : "");
	    $codProduto = isset($_POST['codProduto']) ? $_POST['codProduto'] : "";
	    $fotoAntiga = $produtoDAO->buscarFotoPorCodigo($codProduto);

    if(!empty(isset($_FILES['fotoProduto']) ? $_FILES['fotoProduto'] : "")) {
		$novaFoto = isset($_FILES['fotoProduto']) ? $_FILES['fotoProduto'] : "";
	    $resultado = explode(".", $novaFoto["name"]);
	    $nomeNovaFoto = $resultado[0];
	    $tipoArqNovo = $resultado[1];
	    if ($tipoArqNovo == "png" or $tipoArqNovo == "jpg" or $tipoArqNovo == "jpeg"){
	        $novoNovoNome = "produto-".md5(time()*rand()).".".$tipoArqNovo;
	        move_uploaded_file($novaFoto["tmp_name"], "imgs/produtos/$novoNovoNome");
			$produtoModel->setFotoProduto($novoNovoNome);
	        $produtoDAO->atualizar($produtoModel);    
		} else {
	        $produtoDAO->atualizarSemFoto($produtoModel);    
		}
	}
	//apagador de imag
	if (!empty($fotoAntiga)) {
        $caminhoFotoAntiga = "imgs/produtos/" . $fotoAntiga;
        if (file_exists($caminhoFotoAntiga)) {
            unlink($caminhoFotoAntiga);
        }
    }
	header("location:adminView.php?msg=editado");
		
	}		

?>