<!-- TABELA ADMIN -->
<div class="container-xl">
	<div class="table-responsive">
		<div class="table-wrapper">
			<div class="table-title">
				<div class="row">
					<div class="col-sm-6">
						<h2>Gerenciar <b>Administradores</b></h2>
					</div>
					<div class="col-sm-6">
						<a href="#addAdminModal" class="btn btn-success" data-toggle="modal"><i class="material-icons">&#xE147;</i> <span>Adicionar novo</span></a>						
					</div>
				</div>
			</div>
			<div class="row">
				<form method="GET" class="col-12 mb-2">
					<div class="input-group">
					     	<input class="form-control py-2" type="search" name="pesquisaAdmin" placeholder="Pesquisar administradores" value="" id="example-search-input">
					      	<span class="input-group-append">
					        	<button class="btn btn-outline-secondary" type="submit" name="acao" value="PesquisarAdmin">
					            	<i class="fa fa-search"></i>
					        	</button>
					      	</span>
					</div>
		        </form>
			</div>
			<table class="table table-striped table-hover">
				<thead>
					<tr>
						<th>Foto</th>
						<th>Nome</th>
						<th>Email</th>
						<th>Login</th>
						<th>Senha</th>
						<th>Ações</th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ($admins as $admin) {		?>
					<tr>
						<td class="align-items-center">
							<img src="imgs/admins/<?=$admin ['foto']?>" class="rounded-circle" style="height: 100px; width: 100px;">
						</td>	
						<td><?=$admin ['nome']?></td>
						<td><?=$admin ['email']?></td>
						<td><?=$admin ['login']?></td>
						<td><?=$admin ['senha']?></td>
						<td>
							<a href="#editAdminModal" class="edit" data-toggle="modal"><i class="material-icons" data-toggle="tooltip" title="Editar" onclick="editarAdmin(<?=$admin ['cod']?>,'<?=$admin ['nome']?>','<?=$admin ['email']?>','<?=$admin ['login']?>','<?=$admin ['senha']?>','<?=$admin ['foto']?>')">&#xE254;</i></a>
							<a href="#deleteAdminModal" class="delete" data-toggle="modal"><i class="material-icons" data-toggle="tooltip" title="Apagar" onclick="excluirAdmin(<?=$admin ['cod']?>)">&#xE872;</i></a>
						</td>
					</tr>
					<?php  }?>
				</tbody> 
			</table>
		</div>
	</div>   
	<!-- Adicionar Modal HTML -->
	<div id="addAdminModal" class="modal fade">
		<div class="modal-dialog">
			<div class="modal-content">
				<form method="POST" enctype="multipart/form-data" >
					<div class="modal-header">						
						<h4 class="modal-title">Adicionar</h4>
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					</div>
					<div class="modal-body">
						<div class="form-group">
							<label>Nome</label>
							<input type="text" class="form-control" required name="nomeAdmin">
						</div>
						<div class="form-group">
							<label>Email</label>
							<input type="email" class="form-control" required name="emailAdmin">
						</div>			
						<div class="form-group">
							<label>Login</label>
							<input type="text" class="form-control" required name="loginAdmin">
						</div>		
						<div class="form-group">
							<label>Senha</label>
							<input type="text" class="form-control" required name="senhaAdmin">
						</div>
						<div class="form-group">	
							<label>Foto</label>
							<div class="input-group mb-3">
								<div class="custom-file">
								    <input type="file" class="custom-file-input" id="inputGroupFile01" name="fotoAdmin">
								    <label class="custom-file-label" for="inputGroupFile02">Escolha uma foto</label>
								</div>
							</div>	
						</div>		
					</div>
					<div class="modal-footer">
						<input type="button" class="btn btn-default" data-dismiss="modal" value="Cancelar">
						<input type="submit" class="btn btn-success" value="AdicionarAdmin" name="acao">
					</div>
				</form>
			</div>
		</div>
	</div>
	<!-- Edit Modal HTML -->
	<div id="editAdminModal" class="modal fade">
		<div class="modal-dialog">
			<div class="modal-content">
				<form method="POST" enctype="multipart/form-data">
					<div class="modal-header">						
						<h4 class="modal-title">Editar</h4>
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					</div>
					<div class="modal-body">
						<input type="hidden" name="codAdmin" id="editarCodAdmin">
						<div class="form-group d-flex justify-content-center">
							<img id="editarFotoAdmin" class="rounded-circle" style="height: 100px; width: 100px;"> 
						</div>	
						<div class="form-group">
							<label>Nome</label>
							<input type="text" class="form-control" required name="nomeAdmin" id="editarNomeAdmin">
						</div>
						<div class="form-group">
							<label>Email</label>
							<input type="email" class="form-control" required name="emailAdmin" id="editarEmailAdmin">
						</div>	
						<div class="form-group">
							<label>Login</label>
							<input type="text" class="form-control" required name="loginAdmin" id="editarLoginAdmin">
						</div>	
						<div class="form-group">
							<label>Senha</label>
							<input type="text" class="form-control" required name="senhaAdmin" id="editarSenhaAdmin">
						</div>
						<div class="form-group">	
							<label>Foto</label>
							<div class="input-group mb-3">
								<div class="custom-file">
								    <input type="file" class="custom-file-input" id="editarFotoAdmin" name="fotoAdmin">
								    <label class="custom-file-label" for="inputGroupFile02">Escolha uma foto</label>
								</div>
							</div>	
						</div>			
					</div>
					<div class="modal-footer">
						<input type="button" class="btn btn-default" data-dismiss="modal" value="Cancelar">
						<input type="submit" class="btn btn-info" name="acao" value="EditarAdmin">
					</div>
				</form>
			</div>
		</div>
	</div>
	<!-- Delete Modal HTML -->
	<div id="deleteAdminModal" class="modal fade">
		<div class="modal-dialog">
			<div class="modal-content">
				<form method="POST">
					<div class="modal-header">						
						<h4 class="modal-title">Deletar</h4>
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					</div>
					<div class="modal-body">
						<input type="hidden" name="codAdmin" id="excluirCodAdmin">					
						<p>Você tem certeza que deseja deletar isso?</p>
						<p class="text-warning"><small>Esta ação não pode ser desfeita.</small></p>
					</div>
					<div class="modal-footer">
						<input type="button" class="btn btn-default" data-dismiss="modal" value="Cancelar">
						<input type="submit" class="btn btn-danger" name="acao" value="ApagarAdmin">
					</div>
				</form>
			</div>
		</div>
	</div>
     
</div>