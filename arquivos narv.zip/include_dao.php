<?php

	/* @Autor: Dalker Pinheiro
	   Include com todas as Classes e os arquivos de DAO */

	require_once('conexao.php');
 	
	require_once('DAO/UsuarioDAO.php');
	require_once('DAO/AdminDAO.php');
	require_once('DAO/ProdutoDAO.php');
	require_once('DTO/Usuario.php');
	require_once('DTO/Admin.php');
	require_once('DTO/Produto.php');

?>