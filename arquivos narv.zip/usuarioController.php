<?php  
	require_once ("include_dao.php");
	
	$acao= isset($_POST['acao']) ? $_POST['acao'] : "";
	$pesquisa = isset($_GET['pesquisa']) ? $_GET['pesquisa'] : "";
	
	$usuarioModel= new usuario();
	$usuarioDAO= new usuarioDAO();

	$adminModel= new admin();
	$adminDAO= new adminDAO();

	if(empty($pesquisa)){
		$usuarios = $usuarioDAO -> listarTodos();
	}
	else{
		$usuarios = $usuarioDAO->listar($pesquisa);
	}

	if ($acao == "Logar") {
		$login= isset($_POST['login']) ? $_POST['login'] : "";
	    $senha= isset($_POST['senha']) ? $_POST['senha'] : "";
	
	    $resultado = $usuarioDAO->logar($login, $senha);

	    if ($resultado == false) {
	   		echo '<center><span style="color:red;text-align:center;">Login ou senha incorretos!</span></center>';
	    }
		else{
			session_start();
			$_SESSION["usuario"] = $login;
			header("location:index.php");
		}
	}
	if ($acao == "LogarComoAdm"){
		$login= isset($_POST['login']) ? $_POST['login'] : "";
	    $senha= isset($_POST['senha']) ? $_POST['senha'] : "";
	
	    $resultado = $usuarioDAO->logar($login, $senha);

	    if ($resultado == false) {
	   		echo '<center><span style="color:red;text-align:center;">Login ou senha incorretos!</span></center>';
	    }
		else{
			session_start();
			$_SESSION["admin"] = $login;
			header("location:adminView.php");
		}
	}
	else if ($acao=="Adicionar") {

		$foto = isset($_FILES['foto']) ? $_FILES['foto'] : "";

		if(!empty($foto['name']) and ($foto['type'] == "image/jpeg" or $foto['type'] == "image/jpg" or $foto['type'] == "image/png")){
			$resultado = explode(".", $foto['name']);
			$nome = $resultado[0];
			$tipo = $resultado[1];
			$novoNome = ("usuario-".md5(time()*rand()).".".$tipo);
			$destino = "imgs/usuarios/$novoNome";
			move_uploaded_file($foto["tmp_name"], $destino);
		}else{
			$novoNome = "semfoto.png";
		}

		$usuarioModel->setFoto($novoNome);

	    $nome= isset($_POST['nome']) ? $_POST['nome'] : "";
	    $email= isset($_POST['email']) ? $_POST['email'] : "";
	    $login= isset($_POST['login']) ? $_POST['login'] : "";
	    $senha= isset($_POST['senha']) ? $_POST['senha'] : "";
	
		$usuarioModel->setNome($nome);
		$usuarioModel->setEmail($email);
		$usuarioModel->setLogin($login);
		$usuarioModel->setSenha($senha);

	 	$resultado = $usuarioDAO->inserir($usuarioModel);
	 header("location:adminView.php?msg=adicionado");
	}else if ($acao=="Cadastrar") {
		$foto = isset($_FILES['foto']) ? $_FILES['foto'] : "";

		if(!empty($foto['name']) and ($foto['type'] == "image/jpeg" or $foto['type'] == "image/jpg" or $foto['type'] == "image/png")){
			$resultado = explode(".", $foto['name']);
			$nome = $resultado[0];
			$tipo = $resultado[1];
			$novoNome = ("usuario-".md5(time()*rand()).".".$tipo);
			$destino = "imgs/usuarios/$novoNome";
			move_uploaded_file($foto["tmp_name"], $destino);
		}else{
			$novoNome = "semfoto.png";
		}
	    $nome= isset($_POST['nome']) ? $_POST['nome'] : "";
	    $email= isset($_POST['email']) ? $_POST['email'] : "";
	    $login= isset($_POST['login']) ? $_POST['login'] : "";
	    $senha= isset($_POST['senha']) ? $_POST['senha'] : "";

		if (count($adminDAO->listarTodosAdmin()) == 0) {
			$adminModel->setCodAdmin($codAdmin);
			$adminModel->setNomeAdmin($nomeAdmin);
			$adminModel->setEmailAdmin($emailAdmin);
			$adminModel->setLoginAdmin($loginAdmin);
			$adminModel->setSenhaAdmin($senhaAdmin);
			$adminModel->setFotoAdmin($novoNome);
			$resultado = $adminDAO->inserir($adminModel);
			if($resultado != false){
				session_start();
				$_SESSION['admin'] = $adminModel->getLogin($loginAdmin);
			}
		}
		else{
			$usuarioModel->setFoto($novoNome);
			$usuarioModel->setCod($cod);
			$usuarioModel->setNome($nome);
			$usuarioModel->setEmail($email);
			$usuarioModel->setLogin($login);
			$usuarioModel->setSenha($senha);
			$resultado = $usuarioDAO->inserir($usuarioModel);			
			if($resultado != false){
				session_start();
				$_SESSION['usuario'] = $usuarioModel->getLogin($login);
			}
		}
	 	header("location:cadastro.php?msg=adicionado");	
	}		
	else if ($acao=="Apagar") {
	    $cod= isset($_POST['cod']) ? $_POST['cod'] : "";
	 	$usuarioDAO->deletar($cod);
	 	header("location:adminView.php?msg=excluido");
	}		
	else if ($acao=="Editar"){
	    $usuarioModel->setCod(isset($_POST['cod']) ? $_POST['cod'] : "");
	    $usuarioModel->setNome(isset($_POST['nome']) ? $_POST['nome'] : "");
	    $usuarioModel->setEmail(isset($_POST['email']) ? $_POST['email'] : "");
	    $usuarioModel->setLogin(isset($_POST['login']) ? $_POST['login'] : "");
	    $usuarioModel->setSenha(isset($_POST['senha']) ? $_POST['senha'] : "");
	    $cod = isset($_POST['cod']) ? $_POST['cod'] : "";
	    $fotoAntiga = $usuarioDAO->buscarFotoPorCodigo($cod);

    if(!empty(isset($_FILES['foto']) ? $_FILES['foto'] : "")) {
		$novaFoto = isset($_FILES['foto']) ? $_FILES['foto'] : "";
	    $resultado = explode(".", $novaFoto["name"]);
	    $nomeNovaFoto = $resultado[0];
	    $tipoArqNovo = $resultado[1];
	    if ($tipoArqNovo == "png" or $tipoArqNovo == "jpg" or $tipoArqNovo == "jpeg"){
	        $novoNovoNome = "usuario-".md5(time()*rand()).".".$tipoArqNovo;
	        move_uploaded_file($novaFoto["tmp_name"], "imgs/usuarios/$novoNovoNome");
			$usuarioModel->setFoto($novoNovoNome);
	        $usuarioDAO->atualizar($usuarioModel);    
		} else {
	        $usuarioDAO->atualizarSemFoto($usuarioModel);    
		}
	}
	//apagador de imag
	if (!empty($fotoAntiga)) {
        $caminhoFotoAntiga = "imgs/usuarios/" . $fotoAntiga;
        if (file_exists($caminhoFotoAntiga)) {
            unlink($caminhoFotoAntiga);
        }
    }
	header("location:adminView.php?msg=editado");
		
	}		

?>