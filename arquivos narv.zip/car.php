	if (!isset($_SESSION['carrinho'])) {
		
		$_SESSION['carrinho'] = array();
	}
	include("include_dao.php");
	$produtoDAO = new ProdutoDAO();
	$produtos = $produtoDAO->listarTodos();

onclick="adicionarProduto(<?=$produto['Cod']?>)"