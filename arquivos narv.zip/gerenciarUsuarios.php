<!-- TABELA USUARIO -->
<div class="container-xl">
	<div class="table-responsive">
		<div class="table-wrapper">
			<div class="table-title">
				<div class="row">
					<div class="col-sm-6">
						<h2>Gerenciar <b>Usuários</b></h2>
					</div>
					<div class="col-sm-6">
						<a href="#addEmployeeModal" class="btn btn-success" data-toggle="modal"><i class="material-icons">&#xE147;</i> <span>Adicionar novo</span></a>						
					</div>
				</div>
			</div>
			<div class="row">
				<form method="GET" class="col-12 mb-2">
					<div class="input-group">
					     	<input class="form-control py-2" type="search" name="pesquisa" placeholder="Pesquisar usuários" value="" id="example-search-input">
					      	<span class="input-group-append">
					        	<button class="btn btn-outline-secondary" type="submit" name="acao" value="Pesquisar">
					            	<i class="fa fa-search"></i>
					        	</button>
					      	</span>
					</div>
		        </form>
			</div>
			<table class="table table-striped table-hover">
				<thead>
					<tr>
						<th>Foto</th>
						<th>Nome</th>
						<th>Email</th>
						<th>Login</th>
						<th>Senha</th>
						<th>Ações</th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ($usuarios as $usuario) {		?>
					<tr>
						<td class="align-items-center">
							<img src="imgs/usuarios/<?=$usuario ['foto']?>" class="rounded-circle" style="height: 100px; width: 100px;">
						</td>
						<td><?=$usuario ['nome']?></td>
						<td><?=$usuario ['email']?></td>
						<td><?=$usuario ['login']?></td>
						<td><?=$usuario ['senha']?></td>
						<td>
							<a href="#editEmployeeModal" class="edit" data-toggle="modal"><i class="material-icons" data-toggle="tooltip" title="Editar" onclick="editarUsuario(<?=$usuario ['cod']?>,'<?=$usuario ['nome']?>','<?=$usuario ['email']?>','<?=$usuario ['login']?>','<?=$usuario ['senha']?>','<?=$usuario ['foto']?>')">&#xE254;</i></a>
							<a href="#deleteEmployeeModal" class="delete" data-toggle="modal"><i class="material-icons" data-toggle="tooltip" title="Apagar" onclick="excluirUsuario(<?=$usuario ['cod']?>)">&#xE872;</i></a>
						</td>
					</tr>
					<?php  }?>
				</tbody>
			</table>
		</div>
	</div>   
	<!-- Adicionar Modal HTML -->
	<div id="addEmployeeModal" class="modal fade">
		<div class="modal-dialog">
			<div class="modal-content">
				<form method="POST" enctype="multipart/form-data" >
					<div class="modal-header">						
						<h4 class="modal-title">Adicionar</h4>
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					</div>
					<div class="modal-body">
						<div class="form-group">
							<label>Nome</label>
							<input type="text" class="form-control" required name="nome">
						</div>
						<div class="form-group">
							<label>Email</label>
							<input type="email" class="form-control" required name="email">
						</div>			
						<div class="form-group">
							<label>Login</label>
							<input type="text" class="form-control" required name="login">
						</div>		
						<div class="form-group">
							<label>Senha</label>
							<input type="text" class="form-control" required name="senha">
						</div>
						<div class="form-group">	
							<label>Foto</label>
							<div class="input-group mb-3">
								<div class="custom-file">
								    <input type="file" class="custom-file-input" id="inputGroupFile01" name="foto">
								    <label class="custom-file-label" for="inputGroupFile02">Escolha uma foto</label>
								</div>
							</div>	
						</div>		
					</div>
					<div class="modal-footer">
						<input type="button" class="btn btn-default" data-dismiss="modal" value="Cancelar">
						<input type="submit" class="btn btn-success" value="Adicionar" name="acao">
					</div>
				</form>
			</div>
		</div>
	</div>
	<!-- Edit Modal HTML -->
	<div id="editEmployeeModal" class="modal fade">
		<div class="modal-dialog">
			<div class="modal-content">
				<form method="POST" enctype="multipart/form-data">
					<div class="modal-header">						
						<h4 class="modal-title">Editar</h4>
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					</div>
					<div class="modal-body">
						<input type="hidden" name="cod" id="editarCod">
						<div class="form-group d-flex justify-content-center">
							<img id="editarFoto" class="rounded-circle" style="height: 100px; width: 100px;"> 
						</div>	
						<div class="form-group">
							<label>Nome</label>
							<input type="text" class="form-control" required name="nome" id="editarNome">
						</div>
						<div class="form-group">
							<label>Email</label>
							<input type="email" class="form-control" required name="email" id="editarEmail">
						</div>	
						<div class="form-group">
							<label>Login</label>
							<input type="text" class="form-control" required name="login" id="editarLogin">
						</div>	
						<div class="form-group">
							<label>Senha</label>
							<input type="text" class="form-control" required name="senha" id="editarSenha">
						</div>
						<div class="form-group">	
							<label>Foto</label>
							<div class="input-group mb-3">
								<div class="custom-file">
								    <input type="file" class="custom-file-input" id="editarFoto" name="foto">
								    <label class="custom-file-label" for="inputGroupFile02">Escolha uma foto</label>
								</div>
							</div>	
						</div>			
					</div>
					<div class="modal-footer">
						<input type="button" class="btn btn-default" data-dismiss="modal" value="Cancelar">
						<input type="submit" class="btn btn-info" name="acao" value="Editar">
					</div>
				</form>
			</div>
		</div>
	</div>
	<!-- Delete Modal HTML -->
	<div id="deleteEmployeeModal" class="modal fade">
		<div class="modal-dialog">
			<div class="modal-content">
				<form method="POST">
					<div class="modal-header">						
						<h4 class="modal-title">Deletar</h4>
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					</div>
					<div class="modal-body">
						<input type="hidden" name="cod" id="excluirCod">					
						<p>Você tem certeza que deseja deletar isso?</p>
						<p class="text-warning"><small>Esta ação não pode ser desfeita.</small></p>
					</div>
					<div class="modal-footer">
						<input type="button" class="btn btn-default" data-dismiss="modal" value="Cancelar">
						<input type="submit" class="btn btn-danger" name="acao" value="Apagar">
					</div>
				</form>
			</div>
		</div>
	</div>
     
</div>