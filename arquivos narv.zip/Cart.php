 <?php 
  				
  					
$total = 0;
$quantidade = 0;

						
if (isset($_SESSION['carrinho'])) {
   $produtos_no_carrinho = array(); 

    
    foreach ($_SESSION['carrinho'] as $produto_id) {
        if (isset($produtos_no_carrinho[$produto_id])) {
            $produtos_no_carrinho[$produto_id]++;
        } else {
            $produtos_no_carrinho[$produto_id] = 1;
        }
    }

    foreach ($produtos_no_carrinho as $produto_id => $quantidade) {
        // Carrega o produto pelo ID
        $item = $produtoDAO->carregar($produto_id);

        // Verifica se o produto foi carregado corretamente
        if (is_array($item) && isset($item['valor'])) {
                            
                    ?>
 

   
						    <tbody>
						      <tr class="text-center">
						        <td class="product-remove"><a href="#" class="remove"  onclick="removeProduto(<?=$produto ['cod']?>)"><span class="ion-ios-close"></span></a></td>
						        
						        <td class="image-prod"><div class="img" style="background-image:url(imgs/produtos/<?=$produto ['foto']?>);"></div></td>
						        
						        <td class="product-name">
						        	<h3><?=$produto ['nome']?></h3>
						        	<p><?=$produto ['tipo']?></p>
						        </td>
						        
						        <td class="price">R$<?=$produto ['preco']?></td>
						        		
						       				<div class="input-group mb-3">
					             	 <td class="price">
					               <?=$quantidade?><button type="button" class="btn btn-light btn-circle btn-sm" name="acao" value="add" >+</button>
					             	 
					             	 	
					             	 </td>
					          	</div>
					           
						        <td class="total">R$<?=$produto ['preco'] * $quantidade?></td>
                  
                    	 </tr>


					
						     
						       <?php 
                 
                               $total += floatval($produto ['preco'] * $quantidade);
            									
                                }
                            }
                        }
                    ?>



?>