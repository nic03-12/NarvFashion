<?php

	/* @Autor: Dalker Pinheiro
	   Classe DAO */
	   
class usuarioDAO{

	//Carrega um elemento pela chave primária
	public function carregar($cod){
		include("conexao.php");
		$sql = 'SELECT * FROM usuario WHERE cod = :cod';
		$consulta = $conexao->prepare($sql);
		$consulta->bindValue(":cod",$cod);
		$consulta->execute();
		return ($consulta->fetchAll(PDO::FETCH_ASSOC));
	}

	//Loga um usuário
	public function logar($login,$senha){
		include("conexao.php");
		$sql = 'SELECT * FROM usuario WHERE login = :login and senha = :senha';
		$consulta = $conexao->prepare($sql);
		$consulta->bindValue(":login",$login);
		$consulta->bindValue(":senha",$senha);
		$consulta->execute();
		return ($consulta->fetch(PDO::FETCH_ASSOC));
	}
	public function login($testeLogin){
		include("conexao.php");
		$sql = 'SELECT * FROM usuario WHERE login = :testeLogin';
		$consulta = $conexao->prepare($sql);
		$consulta->bindValue(":testeLogin",$login);
		$consulta->execute();
		return ($consulta->fetch(PDO::FETCH_ASSOC));
	}


	//Lista todos os elementos da tabela
	public function listarTodos(){
		include("conexao.php");
		$sql = 'SELECT * FROM usuario';
		$consulta = $conexao->prepare($sql);
		$consulta->execute();
		return ($consulta->fetchAll(PDO::FETCH_ASSOC));
	}
	
	//Lista todos os elementos da tabela listando ordenados por uma coluna específica
	public function listarTodosOrgenandoPor($coluna){
		include("conexao.php");
		$sql = 'SELECT * FROM usuario ORDER BY '.$coluna;
		$consulta = $conexao->prepare($sql);
		$consulta->execute();
		return ($consulta->fetchAll(PDO::FETCH_ASSOC));
	}

	//Lista todos os elementos da tabela listando ordenados por uma coluna específica
	public function listar($pesquisa){
		include("conexao.php");
		$sql = 'SELECT * FROM usuario WHERE nome LIKE :pesquisa';
		$consulta = $conexao->prepare($sql);
		$pesquisa = "%".$pesquisa."%";
		$consulta->bindValue(":pesquisa",$pesquisa);
		$consulta->execute();
		return ($consulta->fetchAll(PDO::FETCH_ASSOC));
	}
	
	//Apaga um elemento da tabela
	public function deletar($cod){
		include("conexao.php");
		$sql = 'DELETE FROM usuario WHERE cod = :cod';
		$consulta = $conexao->prepare($sql);
		$consulta->bindValue(":cod",$cod);
		if($consulta->execute())
			return true;
		else
			return false;
	}
	
	//Insere um elemento na tabela
	public function inserir($u){
		include("conexao.php");
		$sql = 'INSERT INTO usuario (nome, login, senha, email, foto) VALUES (:nome, :login, :senha, :email, :foto)';
		$consulta = $conexao->prepare($sql);
		$consulta->bindValue(':nome',$u->getNome());  
		$consulta->bindValue(':login',$u->getLogin()); 
		$consulta->bindValue(':senha',$u->getSenha()); 
		$consulta->bindValue(':email',$u->getEmail()); 
		$consulta->bindValue(':foto',$u->getFoto()); 
		if($consulta->execute())
			return true;
		else
			return false;
	}
	
	//Atualiza um elemento na tabela
	public function atualizar($u){
		include("conexao.php");
		$sql = 'UPDATE usuario SET cod = :cod, nome = :nome, login = :login, senha = :senha, email = :email, foto = :foto WHERE cod = :cod';
		$consulta = $conexao->prepare($sql);
		$consulta->bindValue(':cod',$u->getCod()); 
		$consulta->bindValue(':nome',$u->getNome());
		$consulta->bindValue(':login',$u->getLogin()); 
		$consulta->bindValue(':senha',$u->getSenha()); 
		$consulta->bindValue(':email',$u->getEmail()); 
		$consulta->bindValue(':foto',$u->getFoto()); 
		if($consulta->execute())
			return true;
		else
			return false;
	}

	
	//Atualiza um elemento na tabela
	public function atualizarSemFoto($u){
		include("conexao.php");
		$sql = 'UPDATE usuario SET cod = :cod, nome = :nome, login = :login, senha = :senha, email = :email WHERE cod = :cod';
		$consulta = $conexao->prepare($sql);
		$consulta->bindValue(':cod',$u->getCod()); 
		$consulta->bindValue(':nome',$u->getNome()); 
		$consulta->bindValue(':login',$u->getLogin()); 
		$consulta->bindValue(':senha',$u->getSenha()); 
		$consulta->bindValue(':email',$u->getEmail()); 
		if($consulta->execute())
			return true;
		else
			return false;
	}

	//Apaga todos os elementos da tabela
	public function limparTabela(){
		include("conexao.php");
		$sql = 'DELETE FROM usuario';
		$consulta = $conexao->prepare($sql);
		if($consulta->execute())
			return true;
		else
			return false;
	}
	public function buscarFotoPorCodigo($cod){
		include("conexao.php");
		include("../conexao.php");
	    $sql = "SELECT foto FROM usuario WHERE cod = :cod";
	    $consulta = $conexao->prepare($sql);
	    $consulta->bindValue(':cod', $cod);
	    $consulta->execute();
	    $resultado = $consulta->fetch(PDO::FETCH_ASSOC);
	    return ($resultado['foto']);

	}
}
?>