<?php

	/* @Autor: Dalker Pinheiro
	   Classe DAO */
	   
class adminDAO{

	//Carrega um elemento pela chave primária
	public function carregar($codAdmin){
		include("conexao.php");
		$sql = 'SELECT * FROM admin WHERE cod = :cod';
		$consulta = $conexao->prepare($sql);
		$consulta->bindValue(":cod",$codAdmin);
		$consulta->execute();
		return ($consulta->fetchAll(PDO::FETCH_ASSOC));
	}

	//Loga um usuário
	public function logar($loginAdmin,$senhaAdmin){
		include("conexao.php");
		$sql = 'SELECT * FROM admin WHERE login = :login and senha = :senha';
		$consulta = $conexao->prepare($sql);
		$consulta->bindValue(":login",$loginAdmin);
		$consulta->bindValue(":senha",$senhaAdmin);
		$consulta->execute();
		return ($consulta->fetch(PDO::FETCH_ASSOC));
	}

	//Lista todos os elementos da tabela
	public function listarTodosAdmin(){
		include("conexao.php");
		$sql = 'SELECT * FROM admin';
		$consulta = $conexao->prepare($sql);
		$consulta->execute();
		return ($consulta->fetchAll(PDO::FETCH_ASSOC));
	}
	
	//Lista todos os elementos da tabela listando ordenados por uma coluna específica
	public function listarTodosOrgenandoPor($coluna){
		include("conexao.php");
		$sql = 'SELECT * FROM admin ORDER BY '.$coluna;
		$consulta = $conexao->prepare($sql);
		$consulta->execute();
		return ($consulta->fetchAll(PDO::FETCH_ASSOC));
	}

	//Lista todos os elementos da tabela listando ordenados por uma coluna específica
	public function listarAdmin($pesquisaAdmin){
		include("conexao.php");
		$sql = 'SELECT * FROM admin WHERE nome LIKE :pesquisa';
		$consulta = $conexao->prepare($sql);
		$pesquisa = "%".$pesquisaAdmin."%";
		$consulta->bindValue(":pesquisa",$pesquisaAdmin);
		$consulta->execute();
		return ($consulta->fetchAll(PDO::FETCH_ASSOC));
	}
	
	//Apaga um elemento da tabela
	public function deletar($codAdmin){
		include("conexao.php");
		$sql = 'DELETE FROM admin WHERE cod = :cod';
		$consulta = $conexao->prepare($sql);
		$consulta->bindValue(":cod",$codAdmin);
		if($consulta->execute())
			return true;
		else
			return false;
	}
	
	//Insere um elemento na tabela
	public function inserir($a){
		include("conexao.php");
		$sql = 'INSERT INTO admin (nome, login, senha, email, foto) VALUES (:nome, :login, :senha, :email, :foto)';
		$consulta = $conexao->prepare($sql);
		$consulta->bindValue(':nome',$a->getNomeAdmin());
		$consulta->bindValue(':login',$a->getLoginAdmin()); 
		$consulta->bindValue(':senha',$a->getSenhaAdmin()); 
		$consulta->bindValue(':email',$a->getEmailAdmin()); 
		$consulta->bindValue(':foto',$a->getFotoAdmin()); 
		if($consulta->execute())
			return true;
		else
			return false;
	}
	
	//Atualiza um elemento na tabela
	public function atualizar($a){
		include("conexao.php");
		$sql = 'UPDATE admin SET cod = :cod, nome = :nome, login = :login, senha = :senha, email = :email, foto = :foto WHERE cod = :cod';
		$consulta = $conexao->prepare($sql);
		$consulta->bindValue(':cod',$a->getCodAdmin()); 
		$consulta->bindValue(':nome',$a->getNomeAdmin());
		$consulta->bindValue(':login',$a->getLoginAdmin()); 
		$consulta->bindValue(':senha',$a->getSenhaAdmin()); 
		$consulta->bindValue(':email',$a->getEmailAdmin());
		$consulta->bindValue(':foto',$a->getFotoAdmin()); 
		if($consulta->execute())
			return true;
		else
			return false;
	}

	
	//Atualiza um elemento na tabela
	public function atualizarSemFoto($a){
		include("conexao.php");
		$sql = 'UPDATE admin SET cod = :cod, nome = :nome, login = :login, senha = :senha, email = :email, WHERE cod = :cod';
		$consulta = $conexao->prepare($sql);
		$consulta->bindValue(':cod',$a->getCodAdmin()); 
		$consulta->bindValue(':nome',$a->getNomeAdmin());   
		$consulta->bindValue(':login',$a->getLoginAdmin()); 
		$consulta->bindValue(':senha',$a->getSenhaAdmin()); 
		$consulta->bindValue(':email',$a->getEmailAdmin());  
		if($consulta->execute())
			return true;
		else
			return false;
	}

	//Apaga todos os elementos da tabela
	public function limparTabela(){
		include("conexao.php");
		$sql = 'DELETE FROM admin';
		$consulta = $conexao->prepare($sql);
		if($consulta->execute())
			return true;
		else
			return false;
	}
	public function buscarFotoPorCodigo($codAdmin){
		include("conexao.php");
		include("../conexao.php");
	    $sql = "SELECT foto FROM admin WHERE cod = :cod";
	    $consulta = $conexao->prepare($sql);
	    $consulta->bindValue(':cod', $codAdmin);
	    $consulta->execute();
	    $resultado = $consulta->fetch(PDO::FETCH_ASSOC);
	    return ($resultado['fotoAdmin']);

	}
}
?>