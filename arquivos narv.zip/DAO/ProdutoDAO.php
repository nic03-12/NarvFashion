<?php

	/* @Autor: Dalker Pinheiro
	   Classe DAO */
	   
class produtoDAO{

	//Carrega um elemento pela chave primária
	public function carregar($codProduto){
		include("conexao.php");
		$sql = 'SELECT * FROM produto WHERE cod = :cod';
		$consulta = $conexao->prepare($sql);
		$consulta->bindValue(":cod",$codProduto);
		$consulta->execute();
		return ($consulta->fetch(PDO::FETCH_ASSOC));
	}

	//Lista todos os elementos da tabela
	public function listarTodosProduto(){
		include("conexao.php");
		$sql = 'SELECT * FROM produto';
		$consulta = $conexao->prepare($sql);
		$consulta->execute();
		return ($consulta->fetchAll(PDO::FETCH_ASSOC));
	}
	
	//Lista todos os elementos da tabela listando ordenados por uma coluna específica
	public function listarTodosOrgenandoPor($coluna){
		include("conexao.php");
		$sql = 'SELECT * FROM produto ORDER BY '.$coluna;
		$consulta = $conexao->prepare($sql);
		$consulta->execute();
		return ($consulta->fetchAll(PDO::FETCH_ASSOC));
	}

	//Lista todos os elementos da tabela listando ordenados por uma coluna específica
	public function listarProduto($pesquisaProduto){
		include("conexao.php");
		$sql = 'SELECT * FROM produto WHERE nome LIKE :pesquisa';
		$consulta = $conexao->prepare($sql);
		$pesquisa = "%".$pesquisaProduto."%";
		$consulta->bindValue(":pesquisa",$pesquisaProduto);
		$consulta->execute();
		return ($consulta->fetchAll(PDO::FETCH_ASSOC));
	}
	
	//Apaga um elemento da tabela
	public function deletar($codProduto){
		include("conexao.php");
		$sql = 'DELETE FROM produto WHERE cod = :cod';
		$consulta = $conexao->prepare($sql);
		$consulta->bindValue(":cod",$codProduto);
		if($consulta->execute())
			return true;
		else
			return false;
	}
	
	//Insere um elemento na tabela
	public function inserir($p){
		include("conexao.php");
		$sql = 'INSERT INTO produto (nome, id, tipo, foto, preco, quantidade) VALUES (:nome, :id, :tipo, :foto, :preco, :quantidade)';
		$consulta = $conexao->prepare($sql);
		$consulta->bindValue(':nome',$p->getNomeProduto()); 
		$consulta->bindValue(':id',$p->getIdProduto()); 
		$consulta->bindValue(':tipo',$p->getTipoProduto()); 
		$consulta->bindValue(':foto',$p->getFotoProduto()); 
		$consulta->bindValue(':preco',$p->getPrecoProduto()); 
		$consulta->bindValue(':quantidade',$p->getQuantidadeProduto()); 
		if($consulta->execute())
			return true;
		else
			return false;
	}
	
	//Atualiza um elemento na tabela
	public function atualizar($p){
		include("conexao.php");
		$sql = 'UPDATE produto SET cod = :cod, nome = :nome, id = :id, tipo = :tipo, foto = :foto, preco = :preco, quantidade = :quantidade WHERE cod = :cod';
		$consulta = $conexao->prepare($sql);
		$consulta->bindValue(':cod',$p->getCodProduto()); 
		$consulta->bindValue(':nome',$p->getNomeProduto()); 
		$consulta->bindValue(':id',$p->getIdProduto());
		$consulta->bindValue(':tipo',$p->getTipoProduto()); 
		$consulta->bindValue(':foto',$p->getFotoProduto()); 
		$consulta->bindValue(':preco',$p->getPrecoProduto()); 
		$consulta->bindValue(':quantidade',$p->getQuantidadeProduto()); 
		if($consulta->execute())
			return true;
		else
			return false;
	}

	
	//Atualiza um elemento na tabela
	public function atualizarSemFoto($p){
		include("conexao.php");
		$sql = 'UPDATE produto SET cod = :cod, nome = :nome, id = :id, tipo = :tipo, preco = :preco, quantidade = :quantidade WHERE cod = :cod';
		$consulta = $conexao->prepare($sql);
		$consulta->bindValue(':cod',$p->getCodProduto()); 
		$consulta->bindValue(':nome',$p->getNomeProduto()); 
		$consulta->bindValue(':id',$p->getIdProduto());
		$consulta->bindValue(':tipo',$p->getTipoProduto()); 
		$consulta->bindValue(':preco',$p->getPrecoProduto()); 
		$consulta->bindValue(':quantidade',$p->getQuantidadeProduto()); 
		if($consulta->execute())
			return true;
		else
			return false;
	}

	//Apaga todos os elementos da tabela
	public function limparTabela(){
		include("conexao.php");
		$sql = 'DELETE FROM produto';
		$consulta = $conexao->prepare($sql);
		if($consulta->execute())
			return true;
		else
			return false;
	}
	public function buscarFotoPorCodigo($cod){
		include("conexao.php");
		include("../conexao.php");
	    $sql = "SELECT foto FROM produto WHERE cod = :cod";
	    $consulta = $conexao->prepare($sql);
	    $consulta->bindValue(':cod', $codProduto);
	    $consulta->execute();
	    $resultado = $consulta->fetch(PDO::FETCH_ASSOC);
	    return ($resultado['fotoProduto']);

	}
}
?>