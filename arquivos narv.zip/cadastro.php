<?php
    require_once("usuarioController.php");
?>
<!doctype html>
<html lang="pt-BR">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Cadastro</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://kit.fontawesome.com/1d94bf0d1c.js" crossorigin="anonymous"></script>
    <link rel="shortcut icon" type="image/png" href="imgs/Branca.png"/>
  </head>
  <style type="text/css">
    body{
    background-color: black;
    background-image: url("imgs/fundonovo2.png");
    background-size: 1990px;
   }
   h1{
    text-align: center;
    color: white;
    font-family: "Helvética", sans-serif;
    font-size: 50px;
  }
  #logo{
      margin-right: 146px;


  }
  img{
    margin-bottom: 90px;
    width:273px ;
    height:205px;

  }
  #frase{
    font-size: 65px;
    font-family: "Courier New";
    margin-top: 90px;

  }
  .btn-primary {
    color: white;
    background-color: black ;
    border: black;
    --bs-btn-hover-color: black;
    --bs-btn-hover-bg: white;
    --bs-btn-hover-border-color: black;
    --bs-btn-active-color: black;
  } 
  .form-control{
    width: 500px;

  }
  a{
    text-decoration: none;
    color: white;
  }
  a:hover{
    color: black;
  }
 </style>
  <body>

    <div class="container text-center mt-5">
      <?php
        include("msgss.php")  
      ?>
      <div class="row">
        <div class="col mt-2">
            <picture>
              <img src="imgs/Branca.png" class="img-fluid" alt="Login">
            </picture>
        </div>
        <div class="col container text-center">
          <h1 id="logo">Cadastro</h1>
          <form class="form-control" method="POST" enctype="multipart/form-data">
            <div class="row mt-2">
              <div class="input-group flex-nowrap">
                <span class="input-group-text" id="addon-wrapping"><i class="fa-solid fa-pen"></i></span>
                <input type="text" class="form-control" placeholder="Nome" aria-label="nome" aria-describedby="addon-wrapping" name="nome">
              </div>
            </div>
            <div class="row mt-2">
              <div class="input-group flex-nowrap">
                <span class="input-group-text" id="addon-wrapping"><i class="fa-solid fa-envelope"></i></span>
                <input type="text" class="form-control" placeholder="Email" aria-label="email" aria-describedby="addon-wrapping" name="email">
              </div>
            </div>
            <div class="row mt-2">
              <div class="input-group flex-nowrap">
                <span class="input-group-text" id="addon-wrapping"><i class="fa-solid fa-user"></i></span>
                <input type="text" class="form-control" placeholder="Login" aria-label="login" aria-describedby="addon-wrapping" name="login">
              </div>
            </div>
            <div class="row mt-2">
              <div class="input-group flex-nowrap">
                <span class="input-group-text" id="addon-wrapping"><i class="fa-solid fa-key"></i></span>
                <input type="password" class="form-control" placeholder="Senha" aria-label="senha" aria-describedby="addon-wrapping" name="senha">
              </div>
            </div>
            <div class="row mt-2">
              <div class="input-group flex-nowrap">
                <span class="input-group-text" id="addon-wrapping"><i class="fa-solid fa-camera"></i></span>
                <input type="file" class="custom-file-input" placeholder="Foto" aria-label="foto" aria-describedby="addon-wrapping" name="foto">
              </div>
            </div> 
            <div class="row mt-2">
              <div class="col-md-6 offset-md-3">
                <button class="btn btn-primary" type="submit" name="acao" value="Cadastrar">Cadastrar</button>
                <button class="btn btn-primary" type="submit" name="acao"> <a href="login.php">Logar</a></button>
              </div> 
            </div>
          </form>
        </div>
      </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
  </body>
</html>