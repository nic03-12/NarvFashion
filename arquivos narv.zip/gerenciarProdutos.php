<!-- TABELA PRODUTO -->
<div class="container-xl">
	<div class="table-responsive">
		<div class="table-wrapper">
			<div class="table-title">
				<div class="row">
					<div class="col-sm-6">
						<h2>Gerenciar <b>Produtos</b></h2>
					</div>
					<div class="col-sm-6">
						<a href="#addProductModal" class="btn btn-success" data-toggle="modal"><i class="material-icons">&#xE147;</i> <span>Adicionar novo</span></a>						
					</div>
				</div>
			</div>
			<div class="row">
				<form method="GET" class="col-12 mb-2">
					<div class="input-group">
					     	<input class="form-control py-2" type="search" name="pesquisaProduto" placeholder="Pesquisar produtos" value="" id="example-search-input">
					      	<span class="input-group-append">
					        	<button class="btn btn-outline-secondary" type="submit" name="acao" value="PesquisarProduto">
					            	<i class="fa fa-search"></i>
					        	</button>
					      	</span>
					</div>
		        </form>
			</div>
			<table class="table table-striped table-hover">
				<thead>
					<tr>
						<th>Foto</th>
						<th>ID</th>
						<th>Tipo</th>
						<th>Nome</th>
						<th>Preço</th>
						<th>Quantidade</th>
						<th>Ações</th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ($produtos as $produto) {		?>
					<tr>
						<td class="align-items-center">
							<img src="imgs/produtos/<?=$produto ['foto']?>" class="rounded-circle" style="height: 100px; width: 100px;">
						</td>
						<td><?=$produto ['id']?></td>
						<td><?=$produto ['tipo']?></td>
						<td><?=$produto ['nome']?></td>
						<td><?=$produto ['preco']?></td>
						<td><?=$produto ['quantidade']?></td>
						<td>
							<a href="#editProductModal" class="edit" data-toggle="modal"><i class="material-icons" data-toggle="tooltip" title="Editar" onclick="editarProduto(<?=$produto ['cod']?>,'<?=$produto ['id']?>','<?=$produto ['tipo']?>','<?=$produto ['nome']?>','<?=$produto ['foto']?>','<?=$produto ['preco']?>','<?=$produto ['quantidade']?>')">&#xE254;</i></a>
							<a href="#deleteProductModal" class="delete" data-toggle="modal"><i class="material-icons" data-toggle="tooltip" title="Apagar" onclick="excluirProduto(<?=$produto ['cod']?>)">&#xE872;</i></a>
						</td>
					</tr>
					<?php  }?>
				</tbody>
			</table>
		</div>
	</div>   
	<!-- Adicionar Modal HTML -->
	<div id="addProductModal" class="modal fade">
		<div class="modal-dialog">
			<div class="modal-content">
				<form method="POST" enctype="multipart/form-data" >
					<div class="modal-header">						
						<h4 class="modal-title">Adicionar</h4>
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					</div>
					<div class="modal-body">											
						<div class="form-group">
							<label>ID</label>
							<input type="text" class="form-control" required name="idProduto">
						</div>
						<div class="form-group">
							<label>Tipo</label>
							<input type="text" class="form-control" required name="tipoProduto">
						</div>
						<div class="form-group">
							<label>Nome</label>
							<input type="text" class="form-control" required name="nomeProduto">
						</div>
						<div class="form-group">
							<label>Preço</label>
							<input type="text" class="form-control" required name="precoProduto">
						</div>
						<div class="form-group">
							<label>Quantidade</label>
							<input type="text" class="form-control" required name="quantidadeProduto">
						</div>
						<div class="form-group">	
							<label>Foto</label>
							<div class="input-group mb-3">
								<div class="custom-file">
								    <input type="file" class="custom-file-input" id="inputGroupFile01" name="fotoProduto">
								    <label class="custom-file-label" for="inputGroupFile02">Escolha uma foto</label>
								</div>
							</div>	
						</div>		
					</div>
					<div class="modal-footer">
						<input type="button" class="btn btn-default" data-dismiss="modal" value="Cancelar">
						<input type="submit" class="btn btn-success" value="AdicionarProduto" name="acao">
					</div>
				</form>
			</div>
		</div>
	</div>
	<!-- Edit Modal HTML -->
	<div id="editProductModal" class="modal fade">
		<div class="modal-dialog">
			<div class="modal-content">
				<form method="POST" enctype="multipart/form-data">
					<div class="modal-header">						
						<h4 class="modal-title">Editar</h4>
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					</div>
					<div class="modal-body">
						<input type="hidden" name="codProduto" id="editarCodProduto">
						<div class="form-group d-flex justify-content-center">
							<img id="editarFotoProduto" class="rounded-circle" style="height: 100px; width: 100px;"> 
						</div>	
						<div class="form-group">
							<label>ID</label>
							<input type="text" class="form-control" required name="idProduto" id="editarIdProduto">
						</div>
						<div class="form-group">
							<label>Tipo</label>
							<input type="text" class="form-control" required name="tipoProduto" id="editarTipoProduto">
						</div>	
						<div class="form-group">
							<label>Nome</label>
							<input type="text" class="form-control" required name="nomeProduto" id="editarNomeProduto">
						</div>	
						<div class="form-group">
							<label>Preço</label>
							<input type="text" class="form-control" required name="precoProduto" id="editarPrecoProduto">
						</div>	
						<div class="form-group">
							<label>Quantidade</label>
							<input type="text" class="form-control" required name="quantidadeProduto" id="editarQuantidadeProduto">
						</div>
						<div class="form-group">	
							<label>Foto</label>
							<div class="input-group mb-3">
								<div class="custom-file">
								    <input type="file" class="custom-file-input" id="editarFotoProduto" name="fotoProduto">
								    <label class="custom-file-label" for="inputGroupFile02">Escolha uma foto</label>
								</div>
							</div>	
						</div>			
					</div>
					<div class="modal-footer">
						<input type="button" class="btn btn-default" data-dismiss="modal" value="Cancelar">
						<input type="submit" class="btn btn-info" name="acao" value="EditarProduto">
					</div>
				</form>
			</div>
		</div>
	</div>
	<!-- Delete Modal HTML -->
	<div id="deleteProductModal" class="modal fade">
		<div class="modal-dialog">
			<div class="modal-content">
				<form method="POST">
					<div class="modal-header">						
						<h4 class="modal-title">Deletar</h4>
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					</div>
					<div class="modal-body">
						<input type="hidden" name="codProduto" id="excluirCodProduto">					
						<p>Você tem certeza que deseja deletar isso?</p>
						<p class="text-warning"><small>Esta ação não pode ser desfeita.</small></p>
					</div>
					<div class="modal-footer">
						<input type="button" class="btn btn-default" data-dismiss="modal" value="Cancelar">
						<input type="submit" class="btn btn-danger" name="acao" value="ApagarProduto">
					</div>
				</form>
			</div>
		</div>
	</div>
     
</div>